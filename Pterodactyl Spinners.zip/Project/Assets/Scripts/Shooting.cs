﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    public Transform firePoint;
    public GameObject bulletPrefab;

    //I created a fire point for the shooting because I want the bullets to go in a specific direction.
    private void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            Fire();
        }
    }
        void Fire()
        {
            Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        }
    
}
