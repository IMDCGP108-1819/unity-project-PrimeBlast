﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nests : MonoBehaviour {

    //The purpose of the nest is to protect it. Because of that I created a penalty function of losing points by colliding with the meteors.
    private void OnTriggerEnter2D(Collider2D hit)
    {
        if (hit)
            ScoreCounter.scoreValue -= 50;

    }
}
