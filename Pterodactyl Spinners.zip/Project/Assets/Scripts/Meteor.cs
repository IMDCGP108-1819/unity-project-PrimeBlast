﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Meteor : MonoBehaviour
{
    private Rigidbody2D rb2d;

    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    //The meteors are a point earning object but also a hazard one. That is why I have the ScoreCounter script here which is triggered by the player's bullets
    //And I added the player tag trigger so I can have the hazard characteristic of the meteor by sending the player to the end screen.
    void OnTriggerEnter2D(Collider2D hit)
    {
        if (hit.gameObject.tag == "Bullet")
        {
            ScoreCounter.scoreValue += 100;
            Destroy(gameObject);
        }
        if (hit.gameObject.tag == "Player")
           SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
