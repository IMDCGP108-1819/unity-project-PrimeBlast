﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreCounter : MonoBehaviour
{
    //The script for the score counter is made this way so I can add possibilities of adding and subtracting score through other script files.
    public static int scoreValue = 0;
    Text score;
	void Start ()
    {
        score = GetComponent<Text> ();
	}

	void Update ()
    {
        score.text = "Score: " + scoreValue;
	}
}
