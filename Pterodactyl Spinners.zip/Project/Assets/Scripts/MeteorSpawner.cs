﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorSpawner : MonoBehaviour
{
    public GameObject meteor;
    float randx;
    Vector2 spawnLocation;
    public float spawnRate = 2f;
    float nextSpawn = 0.0f;

    //I wanted my meteors to be unpredictable so I made a random spawn function across the top of the screen. That way players do not know where they appear first.
    //I used also the time function because I wanted a regulated spawn of meteors.
    void Update ()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnRate;
            randx = Random.Range(-6.6f, 6.6f);
            spawnLocation = new Vector2(randx, transform.position.y);
            Instantiate(meteor, spawnLocation, Quaternion.identity);
        }
    }

}
