﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TimerCountdown : MonoBehaviour
{
    public Text timer;
    float timeLeft = 120.0f;

    void Start()
    {
        timer = GetComponent<Text> ();
    }

    //I added a timer using the fixedDeltaTime function because it gives an accurate passage of time.
    //For the visible counter I used the Mathf.Round function because by rounding the numbers you only see the seconds on the timer.
    //The main purpose of the timer is to end the game and bring the player to the end screen so I used the scene management functions to achieve this.
    void Update()
    {
        timeLeft -=Time.fixedDeltaTime;
        if (timeLeft > 0.0f)
        timer.text = "Time: " + Mathf.Round (timeLeft);
        else
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
