﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Bullet : MonoBehaviour
{
    public float speed = 20f;
    public Rigidbody2D rb2d;

    //I made the bullets with velocity because I wanted my collision with the meteor to be really fast.
    //I scripted the bullets to destroy the meteors instantly so I used the destroy line.
	void Start ()
    {
        rb2d.velocity = transform.up * speed;
	}
	
    void OnTriggerEnter2D (Collider2D hitInfo)
    {
        Debug.Log(hitInfo.name);
        Destroy(gameObject);
    }
}
